import React from 'react';
import { Link } from 'react-router-dom';

function Navbar() {
  const userName = localStorage.getItem('name');
  return (
    <nav className="navbar">
      <ul className="nav-list">
        <li><Link to="/">Home</Link></li>
        <li><Link to="/products">Products</Link></li>
        <li><Link to="/cart">Cart</Link></li>
        <li><Link to="/checkout">Checkout</Link></li>
        {userName ? (
          <>
            <li>Welcome, {userName}</li>
            <li><button onClick={() => {localStorage.clear(); window.location.reload();}}>Logout</button></li>
          </>
        ) : (
          <>
            <li><Link to="/login">Login</Link></li>
            <li><Link to="/signup">Signup</Link></li>
          </>
        )}
      </ul>
    </nav>
  );
}

export default Navbar;
