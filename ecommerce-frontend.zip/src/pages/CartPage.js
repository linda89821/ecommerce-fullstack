import React, { useContext } from 'react';
import { CartContext } from '../context/CartContext';

function CartPage() {
  const { cartItems } = useContext(CartContext);
  return (
    <div>
      <h2>Your Cart</h2>
      {cartItems.length === 0 ? <p>Cart is empty.</p> :
        cartItems.map((item, i) => <div key={i}>{item.title}</div>)}
    </div>
  );
}

export default CartPage;
