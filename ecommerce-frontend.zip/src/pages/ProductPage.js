import React, { useEffect, useState } from 'react';
import ProductItem from '../components/product/ProductItem';
import axios from 'axios';

function ProductPage() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    axios.get('https://fakestoreapi.com/products').then((res) => setProducts(res.data));
  }, []);

  return (
    <div className="product-page">
      <h1>Products</h1>
      <div className="product-grid">
        {products.map(product => <ProductItem key={product.id} product={product} />)}
      </div>
    </div>
  );
}

export default ProductPage;
