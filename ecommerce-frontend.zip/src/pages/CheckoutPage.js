import React from 'react';

function CheckoutPage() {
  return (
    <div>
      <h2>Checkout</h2>
      <p>Shipping and payment info here</p>
    </div>
  );
}

export default CheckoutPage;
